 const CarApp = {
            // ฐานข้อมูลรถยนต์
            data: [
                {
                    id: 1, brand: "Toyota", name: "Camry HEV Premium", price: "฿1,6xx,xxx",
                    img: "https://www.headlightmag.com/hlmwp/wp-content/uploads/2024/11/Toyota_Camry_HEV_Premium_luxury_Exterior_50.jpg",
                    specs: ["Hybrid", "Auto", "2024"],
                    desc: "ยนตรกรรมซีดานหรูระดับพรีเมียมที่ผสานความประหยัดจากระบบไฮบริดเข้ากับความนุ่มนวลในการขับขี่"
                },
                {
                    id: 2, brand: "Tesla", name: "Model 3 Highland", price: "฿1,5xx,xxx",
                    img: "https://autostation.com/wp-content/uploads/2023/09/updated-tesla-model-3-highland-front-three-quarters-1260x662-1.jpg",
                    specs: ["EV 100%", "Auto", "2024"],
                    desc: "รถยนต์ไฟฟ้าที่มียอดขายสูงสุดทั่วโลก ปรับโฉมใหม่ให้นั่งสบายขึ้นและเก็บเสียงได้เงียบกว่าเดิม"
                },
                {
                    id: 3, brand: "Honda", name: "Civic e:HEV RS", price: "฿1,2xx,xxx",
                    img: "https://www.headlightmag.com/hlmwp/wp-content/uploads/2024/12/Honda_Civic_eHEV_RS_Exterior_47.jpg",
                    specs: ["Hybrid", "Auto", "2024"],
                    desc: "ดีไซน์สปอร์ตเร้าใจพร้อมเทคโนโลยีไฮบริดที่ให้ทั้งอัตราเร่งที่ดีเยี่ยมและความประหยัดน้ำมัน"
                },
                {
                    id: 4, brand: "BYD", name: "Seal AWD", price: "฿1,4xx,xxx",
                    img: "https://www.prachachat.net/wp-content/uploads/2023/09/BYD-SEAL1.jpg",
                    specs: ["EV 100%", "Auto", "2024"],
                    desc: "รถไฟฟ้าสมรรถนะสูง ขับเคลื่อน 4 ล้อ ที่มาพร้อมกับเทคโนโลยีแบตเตอรี่ Blade Battery ที่ปลอดภัยที่สุด"
                },
                {
                    id: 5, brand: "BMW", name: "330e M Sport", price: "฿2,7xx,xxx",
                    img: "https://www.primecarsrentalthailand.com/wp-content/uploads/2023/12/BMW-330e-Front-Left-3.jpg",
                    specs: ["PHEV", "Auto", "2024"],
                    desc: "ความสมบูรณ์แบบของยนตรกรรมจากเยอรมัน มอบการควบคุมที่แม่นยำและพละกำลังจากระบบปลั๊กอินไฮบริด"
                }
            ],

            // ฟังก์ชันเริ่มต้นแอป
            init() {
                this.renderList();
            },

            // แสดงรายการรถในหน้าแรก
            renderList() {
                const container = document.getElementById('car-list-container');
                container.innerHTML = this.data.map(car => `
                    <div class="card" onclick="CarApp.openDetail(${car.id})">
                        <div class="card-img-container">
                            <img src="${car.img}" alt="${car.name}" class="product-img">
                        </div>
                        <div class="card-body">
                            <span class="brand-tag">${car.brand}</span>
                            <h3 class="product-name">${car.name}</h3>
                            <div class="specs">
                                ${car.specs.map(s => `<span>${s}</span>`).join('')}
                            </div>
                            <div class="price-box">
                                <span class="price">${car.price}</span>
                                <button class="btn-view">ดูรายละเอียด</button>
                            </div>
                        </div>
                    </div>
                `).join('');
            },

            // แสดงหน้าจอตาม ID
            showPage(pageId) {
                document.querySelectorAll('.page').forEach(p => p.classList.remove('active'));
                document.getElementById(pageId).classList.add('active');
                window.scrollTo(0, 0);
            },

            // เปิดหน้ารายละเอียดรถ
            openDetail(id) {
                const car = this.data.find(c => c.id === id);
                const view = document.getElementById('detail-view');
                
                view.innerHTML = `
                    <div class="detail-container">
                        <div class="detail-img-box">
                            <img src="${car.img}" alt="${car.name}">
                        </div>
                        <div class="detail-info">
                            <span class="brand-tag">${car.brand}</span>
                            <h2>${car.name}</h2>
                            <p class="detail-price">${car.price}</p>
                            <p class="detail-desc">${car.desc}</p>
                            <div class="detail-specs-grid">
                                <div class="spec-item"><strong>ระบบขับเคลื่อน</strong>${car.specs[0]}</div>
                                <div class="spec-item"><strong>เกียร์</strong>${car.specs[1]}</div>
                                <div class="spec-item"><strong>โมเดลปี</strong>${car.specs[2]}</div>
                                <div class="spec-item"><strong>การรับประกัน</strong>มี</div>
                            </div>
                            <button class="btn-view" style="width:100%; padding:1rem; font-size:1.1rem; margin:1rem;" onclick="alert('จองรถสำเร็จ! เจ้าหน้าที่จะติดต่อท่านกลับโดยเร็วที่สุด')">
                                สนใจสั่งจองคันนี้
                            </button>
                        </div>
                    </div>
                `;
                this.showPage('detail');
            }
        };

        // เริ่มการทำงานเมื่อโหลดหน้าเสร็จ
        window.onload = () => CarApp.init();

        // ฟังก์ชันเสริมสำหรับใช้ใน HTML (ถ้ามี)
        function showPage(id) { CarApp.showPage(id); }